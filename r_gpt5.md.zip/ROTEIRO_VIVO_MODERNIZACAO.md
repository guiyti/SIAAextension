### Roteiro Vivo de Modernização — SIAA Data Extractor (MV3)

Este é o arquivo-fonte de verdade para guiar a modernização desta extensão. Ele é vivo: será atualizado ao final de cada etapa, marcando o que foi concluído, o que mudou e o que ainda está pendente. Ao completar uma etapa, atualize as caixas de seleção e registre no Histórico de Execução.

### Prompt de entrada (cole em qualquer IA antes de começar)

Você é uma IA engenheira de software responsável por executar a PRÓXIMA ETAPA PENDENTE deste roteiro para a extensão SIAA Data Extractor (Manifest V3). Siga estritamente:
- Comunique-se em português Brasil.
- Não quebre a aplicação. Faça mudanças incrementais e testáveis.
- Após concluir a etapa, edite este arquivo: marque a etapa como concluída e adicione um item no "Histórico de Execução" com data, escopo e verificação.
- Use `siaa-config.json` como única fonte de verdade para URLs, presets, chaves de storage e mapeamentos. Evite valores hard-coded (URLs e paths sempre por variáveis/config). 
- Preserve o estilo visual minimalista e sóbrio vigente.
- Remova fallbacks legados da etapa que você modernizar, somente após testes passarem.
- Se ficar bloqueado, registre no "Histórico de Execução" a natureza do bloqueio e proponha 1–3 caminhos de desbloqueio.
- Sempre peça para o usuário testar ao final da etapa (manual: abrir SIAA, iniciar captura, visualizar, exportar) e só então prosseguir para a próxima.

Critérios mínimos para finalizar uma etapa:
- Build e fluxo principal de captura e visualização continuam funcionando.
- Logs e mensagens de erro estão claros.
- Fallbacks da etapa foram removidos ou isolados com flag de configuração.

Formato de atualização ao concluir uma etapa:
- Marque a caixa da etapa: [x]
- Adicione um item no Histórico de Execução com: data, etapa, arquivos editados, testes executados, decisão sobre fallbacks.

### Quadro de status das etapas

- [ ] Etapa 0 — Preparação e baseline (roteiro vivo, critérios, testes manuais)
- [ ] Etapa 1 — Consolidação de configuração (fonte única: `siaa-config.json`)
- [ ] Etapa 2 — Camada de rede unificada (fetch/timeout/charset)
- [ ] Etapa 3 — Camada de storage unificada (APIs de leitura/escrita/merge)
- [ ] Etapa 4 — Utilitários CSV únicos (parse/geração consistentes)
- [ ] Etapa 5 — Barramento de mensagens e contexto (tipos seguros + handshakes)
- [ ] Etapa 6 — Pipeline de extração por configuração (usar `XMLProcessor` c/ config única)
- [ ] Etapa 7 — Popup: saúde de endpoints e seleção de curso sem duplicação
- [ ] Etapa 8 — Viewer modular (renderização, filtros, presets, CSV import/export)
- [ ] Etapa 9 — Performance e dados grandes (virtualização e streaming)
- [ ] Etapa 10 — Observabilidade (níveis de log, códigos de erro, flags de debug)
- [ ] Etapa 11 — Hardening e segurança (permissões, WAR, minimização de recursos)
- [ ] Etapa 12 — Empacotamento e manutenção (estrutura de pastas, docs, release)

Observação: as etapas são independentes e executadas em ordem. Cada etapa tem critérios de aceite e instruções de teste. Ao final de cada etapa bem-sucedida, remova os fallbacks relacionados para manter o sistema moderno.

### Visão geral atual (análise)

Arquitetura:
- `manifest.json` (MV3, service worker)
- `background.js` (service worker): orquestra execução e persiste CSV no `chrome.storage`.
- `content.js` (ponte página ↔ extensão): repassa mensagens e lida com "context invalidated".
- `injected.js` (na página do SIAA): captura ofertas/alunos, monta CSV, possui `fetchXML`, mapeamentos, e fallbacks.
- `popup.html/js` (UI de gatilho e seleção): health check, seleção de curso, inicia extração.
- `viewer.html/js` (UI de análise): visualiza e exporta dados; arquivo grande e multifuncional.
- `config-manager.js`: carrega `siaa-config.json` e fornece utilidades (endpoints, período, presets, etc.).
- `xml-processor.js`: processador genérico baseado em configuração (atualmente espera `xml-config.json`).
- `siaa-config.json`: centraliza endpoints, presets, chaves de storage, mapeamentos e parâmetros de API.

Principais repetições/linhas de melhoria:
- CSV helpers duplicados em `background.js` (ofertas vs. alunos).
- `fetchXML` e detecção de período presentes em `injected.js`, enquanto `config-manager.js` já oferece lógica correlata.
- Mapeamentos de campus e curso espalhados (hard-coded + config); ideal unificar em `siaa-config.json` + `config-manager.js`.
- Mismatch: `popup.js` usa `xmlProcessor.processStep(...)`, porém `xml-processor.js` não expõe esse método e carrega `xml-config.json` (inexistente). É necessário alinhar com `siaa-config.json` e/ou criar API coesa.
- Muitos fallbacks (período padrão, verificação manual de endpoints, métodos "Original") que devem ser removidos gradualmente.
- `viewer.js` monolítico (provável acoplamento entre parsing, estado, render e export), favorecendo modularização.

Metas orientadoras:
- Fonte única de verdade (config central): sem hard-codes.
- Camadas claras (rede, storage, csv, domínio, UI).
- Eliminar fallbacks à medida que a camada moderna entra em produção.
- Mudanças pequenas, reversíveis e testáveis.
- Preservar UI minimalista e leve.

### Plano detalhado por etapa

#### Etapa 0 — Preparação e baseline
Objetivo:
- Estabelecer critérios, testes manuais e estrutura de acompanhamento.
Tarefas:
- Criar este roteiro vivo (concluído ao salvar este arquivo).
- Adicionar seção de testes manuais padrão (abaixo).
- Definir níveis de log por variável de configuração (sem alterar código ainda).
Critérios de aceite:
- Documento disponível no repositório; README aponta para ele.
Testes manuais:
- Abrir popup, iniciar captura, abrir viewer e exportar CSV.
Fallbacks a remover nesta etapa:
- Nenhum (somente documentação).

#### Etapa 1 — Consolidação de configuração
Objetivo:
- Garantir que URLs, chaves de storage, presets e mapeamentos venham exclusivamente do `siaa-config.json` via `config-manager.js`.
Tarefas:
- Mapear todos os locais com valores hard-coded (URLs, mapeamentos, headers).
- Expor getters faltantes no `config-manager.js` (se necessário).
- Substituir em `injected.js`, `popup.js`, `background.js`, `content.js` o uso direto de strings por chamadas ao `config-manager`.
- Alinhar `campusMapping` e nomes de cursos ao storage de mapeamentos.
Critérios de aceite:
- Build ok; extração e viewer funcionam.
- Não há novos hard-codes de URLs/paths.
Testes manuais:
- Capturar ofertas + alunos; conferir nomes de curso/campus.
Fallbacks a remover:
- Remover mapeamentos hard-coded duplicados (onde já houver em config/storage).

#### Etapa 2 — Camada de rede unificada
Objetivo:
- Ter uma única função de fetch (ISO-8859-1, timeout, abort, headers) reutilizável.
Tarefas:
- Criar `utils/net.js` (ou integrar ao `config-manager.js`): `fetchXML(url, {timeout, headers})`.
- Migrar chamadas em `injected.js`, `background.js`, `popup.js` para usar a função unificada.
- Remover `fetchXML` duplicado de `injected.js`.
Critérios de aceite:
- Captura continua funcionando (ofertas + alunos), com logs claros de rede.
Testes manuais:
- Testar interrupção/timeout e mensagens no popup.
Fallbacks a remover:
- Remover fallback de período fixo (ex.: `2025/2`) ao obter período com robustez.

#### Etapa 3 — Camada de storage unificada
Objetivo:
- Centralizar leitura/escrita/deduplicação em um módulo único.
Tarefas:
- Criar `utils/storage.js` com operações tipadas usando as chaves de `siaa-config.json`.
- Migrar `background.js` (ofertas e alunos) para usar as funções de merge padronizadas.
- Remover duplicação de `csvToObjects/objectsToCSV/parseCSVLine` do `background.js` (irão para Etapa 4).
Critérios de aceite:
- Mescla sem duplicatas por chave (Id Oferta / RGM) e preservação de cabeçalhos.
Testes manuais:
- Executar 2 capturas sequenciais e verificar mescla.
Fallbacks a remover:
- Lógica paralela de merge duplicada no background.

#### Etapa 4 — Utilitários CSV únicos
Objetivo:
- Uma única implementação de parsing/geração CSV compatível (aspas, BOM, vírgulas, quebras).
Tarefas:
- Criar `utils/csv.js` com `parseCSV`, `stringifyCSV` e helpers.
- Usar no `background.js` e no `viewer.js` (import/merge/export).
- Remover implementações duplicadas.
Critérios de aceite:
- Export/Import no viewer continuam compatíveis (Excel/UTF-8).
Testes manuais:
- Importar CSV salvo anteriormente e mesclar.
Fallbacks a remover:
- Parsers CSV duplicados.

#### Etapa 5 — Barramento de mensagens e contexto
Objetivo:
- Padronizar mensagens entre `injected` → `content` → `background` com tipos e proteção contra loops/contexto inválido.
Tarefas:
- Criar `utils/messaging.js` com `safePostMessage`, `safeSendMessage`, timeouts e filtros.
- Remover funções de teste do `content.js` e protegê-las por flag de debug.
- Padronizar ações e respostas com esquema simples.
Critérios de aceite:
- Sem loops e com tratamento explícito de `context invalidated`.
Testes manuais:
- Reiniciar a extensão durante captura e checar mensagens de erro.
Fallbacks a remover:
- Repasses e fallbacks manuais redundantes.

#### Etapa 6 — Pipeline de extração por configuração
Objetivo:
- Usar `XMLProcessor` com a MESMA configuração de `siaa-config.json` (evitar `xml-config.json` separado) ou adaptar o processor para ler de `siaa-config.json`.
Tarefas:
- Ajustar `xml-processor.js` para aceitar configuração injetada do `config-manager.js`.
- Expor API coerente (ex.: `extractDataType('ofertas_disciplinas', params)`), e — opcionalmente — `processStep(dataType, stepId)`.
- Alinhar `popup.js`/`injected.js` ao novo contrato e remover o sufixo "Original" dos fallbacks.
Critérios de aceite:
- Captura completa via config (ofertas e alunos) e CSV final idêntico ao atual.
Testes manuais:
- Capturar para diferentes cursos/períodos.
Fallbacks a remover:
- Fallbacks de busca de cursos/periodo/links em `injected.js`.

#### Etapa 7 — Popup: saúde de endpoints e seleção de curso
Objetivo:
- Manter health-check só via `config-manager` e remover checks paralelos.
Tarefas:
- Consolidar `checkEndpointAccess` para usar apenas `configManager.checkEndpointsHealth`.
- Seleção de curso: nomes provenientes do mapeamento/processor; garantir persistência.
Critérios de aceite:
- Mensagens de bloqueio claras (qual endpoint falta) e sem duplicidade.
Testes manuais:
- Simular endpoint off e observar feedback no popup.
Fallbacks a remover:
- Verificações manuais de endpoints do fallback.

#### Etapa 8 — Viewer modular
Objetivo:
- Separar parsing, estado, renderização e exportação em módulos.
Tarefas:
- Extrair módulos: `viewer/state.js`, `viewer/render.js`, `viewer/filters.js`, `viewer/export.js`.
- Manter UI existente e comportamento idêntico.
Critérios de aceite:
- Mesmo desempenho/funcionalidade, código mais legível.
Testes manuais:
- Filtrar, reordenar colunas, presets, copiar dados, exportar/importar.
Fallbacks a remover:
- Hooks utilitários duplicados dentro do `viewer.js`.

#### Etapa 9 — Performance e dados grandes
Objetivo:
- Suporte confortável a milhares de linhas.
Tarefas:
- Implementar renderização virtual (apenas linhas visíveis).
- Streaming de parsing (quando aplicável) e debounce/thresholds.
Critérios de aceite:
- Scroll suave com 50k+ linhas (ambiente de teste); sem travamentos.
Testes manuais:
- Importar CSV grande e medir responsividade.
Fallbacks a remover:
- Gambiarras de UI para aliviar render.

#### Etapa 10 — Observabilidade
Objetivo:
- Logging e erros padronizados por nível (debug/info/warn/error) e códigos.
Tarefas:
- Criar `utils/log.js` com níveis e toggles via `siaa-config.json.developer`.
- Uniformizar mensagens e códigos de erro.
Critérios de aceite:
- Logs úteis para diagnóstico, silenciosos em produção.
Testes manuais:
- Ativar `debugMode` e conferir granularidade.
Fallbacks a remover:
- Logs verbosos e inconsistentes espalhados.

#### Etapa 11 — Hardening e segurança
Objetivo:
- Minimizar superfície de ataque e recursos expostos.
Tarefas:
- Revisar `web_accessible_resources` e remover entradas desnecessárias.
- Confirmar permissões mínimas no `manifest.json`.
Critérios de aceite:
- Tudo funciona com o menor conjunto de permissões/recursos.
Testes manuais:
- Fluxo completo e verificações de console.
Fallbacks a remover:
- Exposições temporárias de arquivos.

#### Etapa 12 — Empacotamento e manutenção
Objetivo:
- Estrutura de pastas clara e docs atualizados.
Tarefas:
- Organizar `utils/`, `viewer/`, `docs/` (se aplicável) e notas de release.
- Checklist de publicação (Chrome Web Store) e verificação de MV3.
Critérios de aceite:
- Build para publicação com notas e changelog atualizados.
Testes manuais:
- Instalar em modo dev e smoke test.
Fallbacks a remover:
- Comentários e blocos mortos temporários.

### Testes manuais padrão (ao final de cada etapa)
- Abrir `home.jsf` no SIAA; aguardar o popup acusar "Pronto para extrair".
- Selecionar curso, iniciar captura; acompanhar progresso sem erros.
- Abrir viewer; aplicar filtros; verificar contadores; exportar CSV.
- Importar CSV exportado e mesclar; confirmar ausência de duplicatas.

### Histórico de Execução (preencha a cada conclusão)
- AAAA-MM-DD — Etapa X concluída — Arquivos alterados: ... — Testes: ... — Fallbacks removidos: ...

### Notas finais
- Preferências do projeto: UI minimalista; URLs/paths variáveis; presets e ordem vindos do `siaa-config.json`.
- Em caso de dúvida de origem de dados, priorize `siaa-config.json` + `config-manager.js`.


